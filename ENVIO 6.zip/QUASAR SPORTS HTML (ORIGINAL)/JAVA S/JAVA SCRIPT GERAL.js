function Pesquisa (){
let input = document.getElementById('BarPesquisa').value
input = input.toLowerCase()
let x = document.getElementsByClassName('produtos')

for(i = 0; i < x.length; i++){
    if(!x[i].innerHTML.toLowerCase().includes(input)){
        x[i].style.display = "none"
    }
    else{
        x[i].style.display = "list-item"
    }
}

}

function MODO_CLARO_E_ESCURO(CorDeFundo, CorDoTexto) {
    document.body.style.backgroundColor = CorDeFundo;
    document.body.style.color = CorDoTexto;
  }

  function MDclaro() {
    document.getElementById("cadastrar-container").style.backgroundColor = "#adadaf";
  }

  function MDescuro() {
    document.getElementById("cadastrar-container").style.backgroundColor = "#181920";
  }

